function closeNav(){
    document.getElementById("mysidenav").style.width="0px";
}
function openNav(){
    document.getElementById("mysidenav").style.width="140px";
}
//time function
const d =new Date();
document.getElementById("demo").innerHTML= d ;